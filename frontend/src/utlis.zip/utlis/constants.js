export const APP_NAME =
"Hospital Appointment Management System";

export const BASE_URL =
"http://localhost:5555";