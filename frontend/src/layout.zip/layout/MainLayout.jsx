import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";

function MainLayout({ children }) {

    return (

        <>

            <Navbar />

            <div className="row">

                <div className="col-md-2">

                    <Sidebar />

                </div>

                <div className="col-md-10">

                    {children}

                </div>

            </div>

        </>

    );
}

export default MainLayout;