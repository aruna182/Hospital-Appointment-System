import api from "../utlis/axiosConfig";

export const getDoctors = () => {
    return api.get("/doctor");
};

export const getDoctorById = (id) => {
    return api.get(`/doctor/${id}`);
};

export const addDoctor = (doctor) => {
    return api.post("/doctor", doctor);
};

export const updateDoctor = (id, doctor) => {
    return api.put(`/doctor/${id}`, doctor);
};

export const deleteDoctor = (id) => {
    return api.delete(`/doctor/${id}`);
};