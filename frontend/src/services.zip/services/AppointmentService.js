import api from "../utlis/axiosConfig";

export const getAppointments = () => {
    return api.get("/appointment");
};

export const getAppointmentById = (id) => {
    return api.get(`/appointment/${id}`);
};

export const bookAppointment = (appointment) => {
    return api.post("/appointment", appointment);
};

export const cancelAppointment = (id) => {
    return api.delete(`/appointment/${id}`);
};