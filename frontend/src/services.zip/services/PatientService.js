import api from "../utlis/axiosConfig";

export const getPatients = () => {
    return api.get("/patient");
};

export const getPatientById = (id) => {
    return api.get(`/patient/${id}`);
};

export const addPatient = (patient) => {
    return api.post("/patient", patient);
};

export const updatePatient = (id, patient) => {
    return api.put(`/patient/${id}`, patient);
};

export const deletePatient = (id) => {
    return api.delete(`/patient/${id}`);
};