import { useEffect,useState } from "react";

import { Link }

from "react-router-dom";

import {

getPatients,
deletePatient

}

from "../../services/PatientService";

function PatientList(){

const [patients,setPatients]=
useState([]);

useEffect(()=>{

loadPatients();

},[]);

const loadPatients=
async()=>{

const response=
await getPatients();

setPatients(
response.data
);

};

const removePatient=
async(id)=>{

await deletePatient(id);

loadPatients();

};

return(

<div className="container mt-4">

<div className="d-flex justify-content-between">

<h2>

Patients List

</h2>

<Link
className="btn btn-success"
to="/addPatient"
>

Add Patient

</Link>

</div>

<table className="table table-bordered mt-3">

<thead>

<tr>

<th>ID</th>

<th>Name</th>

<th>Email</th>

<th>Phone</th>

<th>Issue</th>

<th>Actions</th>

</tr>

</thead>

<tbody>

{

patients.map(

(patient)=>(

<tr
key={
patient.patientId
}
>

<td>
{patient.patientId}
</td>

<td>
{patient.patientName}
</td>

<td>
{patient.email}
</td>

<td>
{patient.phone}
</td>

<td>
{patient.issue}
</td>

<td>

<Link
className="btn btn-warning me-2"
to={`/editPatient/${patient.patientId}`}
>

Edit

</Link>

<button
className="btn btn-danger"
onClick={()=>
removePatient(
patient.patientId
)
}
>

Delete

</button>

</td>

</tr>

)

)

}

</tbody>

</table>

<div className="mt-4 text-center">

<Link
to="/dashboard"
className="btn btn-secondary"
>

🏠 Go To Dashboard

</Link>

</div>

</div>

);

}

export default PatientList;