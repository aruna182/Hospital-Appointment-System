import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { addPatient } from "../../services/PatientService";
import { toast } from "react-toastify";

function AddPatient() {

const navigate=useNavigate();

const [patientName,setPatientName]=useState("");

const [email,setEmail]=useState("");

const [phone,setPhone]=useState("");

const [issue,setIssue]=useState("");

const savePatient=async(e)=>{

e.preventDefault();

await addPatient({

patientName,
email,
phone,
issue

});

toast.success(
"Patient Added Successfully"
);

navigate("/patients");

};

return(

<div className="container mt-5">

<div className="card p-4 shadow">

<h2>Add Patient</h2>

<form onSubmit={savePatient}>

<input
className="form-control mb-3"
placeholder="Patient Name"
onChange={(e)=>
setPatientName(e.target.value)}
/>

<input
className="form-control mb-3"
placeholder="Email"
onChange={(e)=>
setEmail(e.target.value)}
/>

<input
className="form-control mb-3"
placeholder="Phone Number"
onChange={(e)=>
setPhone(e.target.value)}
/>

<input
className="form-control mb-3"
placeholder="Issue"
onChange={(e)=>
setIssue(e.target.value)}
/>

<button className="btn btn-primary">

Save

</button>

</form>

</div>

</div>

);

}

export default AddPatient;