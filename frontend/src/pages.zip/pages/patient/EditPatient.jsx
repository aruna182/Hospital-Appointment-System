import { useEffect, useState } from "react";
import { toast } from "react-toastify";

import {
useParams,
useNavigate,
Link
}

from "react-router-dom";

import {
getPatientById,
updatePatient
}

from "../../services/PatientService";

function EditPatient() {

const { id } = useParams();

const navigate = useNavigate();

const [patientName, setPatientName] = useState("");

const [email, setEmail] = useState("");

const [phone, setPhone] = useState("");

const [issue, setIssue] = useState("");

useEffect(() => {

loadPatient();

}, []);

const loadPatient = async () => {

try {

const response =
await getPatientById(id);

setPatientName(
response.data.patientName
);

setEmail(
response.data.email
);

setPhone(
response.data.phone
);

setIssue(
response.data.issue
);

}

catch {

toast.error(
"Failed To Load Patient"
);

}

};

const updateData = async (e) => {

e.preventDefault();

try {

await updatePatient(

id,

{
patientName,
email,
phone,
issue
}

);

toast.success(
"Patient Updated Successfully"
);

navigate(
"/patients"
);

}

catch {

toast.error(
"Update Failed"
);

}

};

return (

<div className="container mt-5">

<div className="card p-4 shadow">

<h2>

Edit Patient

</h2>

<form onSubmit={updateData}>

<input
className="form-control mb-3"
placeholder="Patient Name"
value={patientName}
onChange={(e)=>
setPatientName(
e.target.value
)}
/>

<input
className="form-control mb-3"
placeholder="Email"
value={email}
onChange={(e)=>
setEmail(
e.target.value
)}
/>

<input
className="form-control mb-3"
placeholder="Phone"
value={phone}
onChange={(e)=>
setPhone(
e.target.value
)}
/>

<input
className="form-control mb-3"
placeholder="Issue"
value={issue}
onChange={(e)=>
setIssue(
e.target.value
)}
/>

<button
className="btn btn-success"
>

Update

</button>

</form>

<div className="mt-3">

<Link
to="/patients"
className="btn btn-secondary"
>

← Go To Patient List

</Link>

</div>

</div>

</div>

);

}

export default EditPatient;