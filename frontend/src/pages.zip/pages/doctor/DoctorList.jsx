import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
getDoctors,
deleteDoctor
}
from "../../services/DoctorService";

function DoctorList() {

const [doctors,setDoctors]=useState([]);
const [search,setSearch]=useState("");

useEffect(()=>{

loadDoctors();

},[]);

const loadDoctors=async()=>{

const response=
await getDoctors();

setDoctors(
response.data
);

};

const removeDoctor=
async(id)=>{

await deleteDoctor(id);

loadDoctors();

};

return(

<div className="container mt-4">

<div className="d-flex justify-content-between">

<h2>
Doctors List
</h2>

<Link
className="btn btn-success"
to="/addDoctor"
>

Add Doctor

</Link>

</div>

<input
className="form-control mb-3"
placeholder="Search Doctor"
onChange={
(e)=>
setSearch(
e.target.value
)
}
/>

<table className="table table-bordered mt-3">

<thead>

<tr>

<th>ID</th>
<th>Name</th>
<th>Specialization</th>
<th>Experience</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

{

doctors

.filter(

doctor=>

doctor
.doctorName
.toLowerCase()
.includes(
search
.toLowerCase()
)

)

.map(

doctor=>(

<tr
key={
doctor
.doctorId
}
>

<td>
{
doctor
.doctorId
}
</td>

<td>
{
doctor
.doctorName
}
</td>

<td>
{
doctor
.specialization
}
</td>

<td>
{
doctor
.experience
}
</td>

<td>

<Link
to={`/editDoctor/${doctor.doctorId}`}
className=
"btn btn-warning me-2"
>

Edit

</Link>

<button
className=
"btn btn-danger"
onClick={
()=>
removeDoctor(
doctor
.doctorId
)
}

>

Cancel

</button>

</td>

</tr>

)

)

}

</tbody>

</table>

<div className="mt-4 text-center">

<Link
to="/dashboard"
className="btn btn-secondary"
>

🏠 Go To Dashboard

</Link>

</div>

</div>

);

}

export default DoctorList;
