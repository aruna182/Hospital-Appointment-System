import { useEffect, useState } from "react";

import { toast }

from "react-toastify";

import {

useNavigate,
useParams,
Link

}

from "react-router-dom";

import {

getDoctorById,
updateDoctor

}

from "../../services/DoctorService";

function EditDoctor() {

const { id } =
useParams();

const navigate =
useNavigate();

const [doctorName, setDoctorName] =
useState("");

const [specialization, setSpecialization] =
useState("");

const [experience, setExperience] =
useState("");

useEffect(() => {

loadDoctor();

}, []);

const loadDoctor = async () => {

try {

const response =
await getDoctorById(id);

setDoctorName(
response.data.doctorName
);

setSpecialization(
response.data.specialization
);

setExperience(
response.data.experience
);

}

catch {

toast.error(
"Failed To Load Doctor"
);

}

};

const updateData = async (e) => {

e.preventDefault();

try {

await updateDoctor(

id,

{

doctorName,
specialization,
experience

}

);

toast.success(
"Doctor Updated Successfully"
);

navigate(
"/doctors"
);

}

catch {

toast.error(
"Update Failed"
);

}

};

return (

<div className="container mt-5">

<div className="card p-4 shadow">

<h2>

Edit Doctor

</h2>

<form onSubmit={updateData}>

<input
className="form-control mb-3"
placeholder="Doctor Name"
value={doctorName}
onChange={(e)=>
setDoctorName(
e.target.value
)}
/>

<input
className="form-control mb-3"
placeholder="Specialization"
value={specialization}
onChange={(e)=>
setSpecialization(
e.target.value
)}
/>

<input
className="form-control mb-3"
placeholder="Experience"
value={experience}
onChange={(e)=>
setExperience(
e.target.value
)}
/>

<button
className="btn btn-success"
>

Update

</button>

</form>

<div className="mt-3">

<Link
to="/doctors"
className="btn btn-secondary"
>

← Go To Doctor List

</Link>

</div>

</div>

</div>

);

}

export default EditDoctor;