import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { addDoctor } from "../../services/DoctorService";
import { toast } from "react-toastify";

function AddDoctor() {

    const navigate = useNavigate();

    const [doctorName, setDoctorName] = useState("");

    const [specialization, setSpecialization] = useState("");

    const [experience, setExperience] = useState("");

    const saveDoctor = async (e) => {

    e.preventDefault();

    try {

        const response = await addDoctor({

            doctorName,
            specialization,
            experience: Number(experience)

        });

        console.log(response);

        toast.success("Doctor Added Successfully");

        navigate("/doctors");

    } catch (error) {

        console.log(error);

        toast.error("Failed to save doctor");

    }
};

    return (

        <div className="container mt-5">

            <div className="card p-4 shadow">

                <h2>Add Doctor</h2>

                <form onSubmit={saveDoctor}>

                    <input
                        className="form-control mb-3"
                        placeholder="Doctor Name"
                        onChange={(e) =>
                            setDoctorName(e.target.value)
                        }
                    />

                    <input
                        className="form-control mb-3"
                        placeholder="Specialization"
                        onChange={(e) =>
                            setSpecialization(e.target.value)
                        }
                    />

                    <input
                        className="form-control mb-3"
                        placeholder="Experience"
                        onChange={(e) =>
                            setExperience(e.target.value)
                        }
                    />

                    <button className="btn btn-primary">

                        Save

                    </button>

                </form>

            </div>

        </div>

    );
}

export default AddDoctor;