import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { registerUser } from "../services/AuthService";

function Register() {

    const navigate = useNavigate();

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [role, setRole] = useState("");

    const handleRegister = async (e) => {

        e.preventDefault();

        try {

            await registerUser({

                username,
                password,
                role

            });

            alert("Registration Successful");

            navigate("/");

        } catch (error) {

            console.log(error);

            alert(
                error?.response?.data ||
                error?.message ||
                "Registration Failed"
            );

        }

    };

    return (

        <div className="container mt-5">

            <div className="card p-4 shadow">

                <h2 className="text-center mb-4">
                    Register
                </h2>

                <form onSubmit={handleRegister}>

                    <input
                        className="form-control mb-3"
                        placeholder="Username"
                        value={username}
                        onChange={(e) =>
                            setUsername(e.target.value)
                        }
                    />

                    <input
                        type="password"
                        className="form-control mb-3"
                        placeholder="Password"
                        value={password}
                        onChange={(e) =>
                            setPassword(e.target.value)
                        }
                    />

                    <input
                        className="form-control mb-3"
                        placeholder="Role"
                        value={role}
                        onChange={(e) =>
                            setRole(e.target.value)
                        }
                    />

                    <button
                        type="submit"
                        className="btn btn-success w-100"
                    >
                        Register
                    </button>

                </form>

                <br />

                <Link to="/">
                    Already have an account?
                </Link>

            </div>

        </div>

    );
}

export default Register;