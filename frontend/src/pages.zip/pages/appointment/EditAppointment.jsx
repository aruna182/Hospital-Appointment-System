import { useState } from "react";
import { Link } from "react-router-dom";

function EditAppointment() {

const [date,setDate]=useState("");

const [time,setTime]=useState("");

const saveChanges=(e)=>{

e.preventDefault();

alert(
"Appointment Updated"
);

};

return(

<div className="container mt-5">

<div className="card p-4 shadow">

<h2>

Edit Appointment

</h2>

<form
onSubmit={saveChanges}
>

<input
type="date"
className="form-control mb-3"
value={date}
onChange={
(e)=>
setDate(
e.target.value
)
}
/>

<input
type="time"
className="form-control mb-3"
value={time}
onChange={
(e)=>
setTime(
e.target.value
)
}
/>

<button
className=
"btn btn-primary w-100"

>

Update

</button>

</form>

<div className="mt-3">

<Link
to="/appointments"
className=
"btn btn-secondary w-100"
>

← Go To Appointment List

</Link>

</div>

</div>

</div>

);

}

export default EditAppointment;
