import { useEffect, useState } from "react";
import { toast } from "react-toastify";

import { useNavigate }

from "react-router-dom";

import { getDoctors }

from "../../services/DoctorService";

import { getPatients }

from "../../services/PatientService";

import { bookAppointment }

from "../../services/AppointmentService";

function BookAppointment() {

    const navigate = useNavigate();

    const [doctors, setDoctors] = useState([]);

    const [patients, setPatients] = useState([]);

    const [doctorId, setDoctorId] = useState("");

    const [patientId, setPatientId] = useState("");

    const [appointmentDate, setAppointmentDate] = useState("");

    const [appointmentTime, setAppointmentTime] = useState("");

    useEffect(() => {

        loadDoctors();

        loadPatients();

    }, []);

    const loadDoctors = async () => {

        const response = await getDoctors();

        setDoctors(response.data);
    };

    const loadPatients = async () => {

        const response = await getPatients();

        setPatients(response.data);
    };

    const saveAppointment = async (e) => {

        e.preventDefault();

        await bookAppointment({

            appointmentDate,
            appointmentTime,
            status: "Booked",

            doctor: {
                doctorId
            },

            patient: {
                patientId
            }

        });

        toast.success(
"Appointment Booked Successfully"
);

        navigate("/appointments");
    };

    return (

        <div className="container mt-5">

            <div className="card shadow p-4">

                <h2>Book Appointment</h2>

                <form onSubmit={saveAppointment}>

                    <select
                        className="form-control mb-3"
                        onChange={(e) =>
                            setDoctorId(e.target.value)
                        }
                    >

                        <option>Select Doctor</option>

                        {

                            doctors.map((doctor) => (

                                <option
key={doctor.doctorId}
value={doctor.doctorId}
>

{doctor.doctorName}
{" - "}
{doctor.specialization}

</option>

                            ))

                        }

                    </select>

                    <select
                        className="form-control mb-3"
                        onChange={(e) =>
                            setPatientId(e.target.value)
                        }
                    >

                        <option>Select Patient</option>

                        {

                            patients.map((patient) => (

                               <option
key={patient.patientId}
value={patient.patientId}
>

{patient.patientName}
{" - "}
{patient.issue}

</option>

                            ))

                        }

                    </select>

                    <input
                        type="date"
                        className="form-control mb-3"
                        onChange={(e) =>
                            setAppointmentDate(e.target.value)
                        }
                    />

                    <input
                        type="time"
                        className="form-control mb-3"
                        onChange={(e) =>
                            setAppointmentTime(e.target.value)
                        }
                    />

                    <button className="btn btn-primary">

                        Book Appointment

                    </button>

                </form>

            </div>

        </div>

    );
}

export default BookAppointment;