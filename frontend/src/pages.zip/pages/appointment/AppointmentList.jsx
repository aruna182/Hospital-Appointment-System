import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { Link } from "react-router-dom";

import {
getAppointments,
cancelAppointment
}

from "../../services/AppointmentService";

function AppointmentList() {

const [appointments,setAppointments]=
useState([]);

useEffect(()=>{

loadAppointments();

},[]);

const loadAppointments=
async()=>{

const response=
await getAppointments();

setAppointments(
response.data
);

};

const removeAppointment=
async(id)=>{

await cancelAppointment(id);

toast.success(
"Appointment Cancelled Successfully"
);

loadAppointments();

};

return(

<div className="container mt-4">

<div className="d-flex justify-content-between">

<h2>

Appointments

</h2>

<Link
className="btn btn-success"
to="/bookAppointment"
>

Book Appointment

</Link>

</div>

<table
className=
"table table-bordered mt-3"
>

<thead>

<tr>

<th>ID</th>

<th>Date</th>

<th>Time</th>

<th>Status</th>

<th>Doctor</th>

<th>Patient</th>

<th>Action</th>

</tr>

</thead>

<tbody>

{

appointments.map(

(appointment)=>(

<tr
key={
appointment
.appointmentId
}
>

<td>
{
appointment
.appointmentId
}
</td>

<td>
{
appointment
.appointmentDate
}
</td>

<td>
{
appointment
.appointmentTime
}
</td>

<td>
{
appointment
.status
}
</td>

<td>

{
appointment
.doctor
?.doctorName
}

</td>

<td>

{
appointment
.patient
?.patientName
}

</td>

<td>

<Link
to={`/editAppointment/${appointment.appointmentId}`}
className=
"btn btn-warning me-2"
>

Edit

</Link>

<button
className=
"btn btn-danger"
onClick={
()=>
removeAppointment(
appointment
.appointmentId
)
}

>

Cancel

</button>

</td>

</tr>

)

)

}

</tbody>

</table>

<div className="mt-4 text-center">

<Link
to="/dashboard"
className="btn btn-secondary"
>

🏠 Go To Dashboard

</Link>

</div>

</div>

);

}

export default AppointmentList;
