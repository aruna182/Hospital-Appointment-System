import { useEffect, useState } from "react";

import { getAppointments }

from "../../services/AppointmentService";

function AppointmentHistory() {

    const [appointments, setAppointments] = useState([]);

    useEffect(() => {

        loadAppointments();

    }, []);

    const loadAppointments = async () => {

        const response = await getAppointments();

        setAppointments(response.data);
    };

    return (

        <div className="container mt-4">

            <h2>Appointment History</h2>

            <table className="table table-striped">

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>

                    </tr>

                </thead>

                <tbody>

                    {

                        appointments.map((appointment) => (

                            <tr key={appointment.appointmentId}>

                                <td>{appointment.appointmentId}</td>

                                <td>{appointment.appointmentDate}</td>

                                <td>{appointment.appointmentTime}</td>

                                <td>{appointment.status}</td>

                            </tr>

                        ))

                    }

                </tbody>

            </table>
            

        </div>

    );
}

export default AppointmentHistory;