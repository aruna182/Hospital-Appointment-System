import { useEffect, useState } from "react";
import MainLayout from "../layout/MainLayout";

import { getDoctors } from "../services/DoctorService";
import { getPatients } from "../services/PatientService";
import { getAppointments } from "../services/AppointmentService";

function Dashboard() {

const [doctorCount,setDoctorCount]=useState(0);

const [patientCount,setPatientCount]=useState(0);

const [appointmentCount,setAppointmentCount]=useState(0);

useEffect(()=>{

loadDashboard();

},[]);

const loadDashboard=async()=>{

try{

const doctors=
await getDoctors();

const patients=
await getPatients();

const appointments=
await getAppointments();

setDoctorCount(
doctors.data.length
);

const now=
new Date();

const activeAppointments=

appointments.data.filter(

(a)=>{

const appointmentDateTime=

new Date(
`${a.appointmentDate}T${a.appointmentTime}`
);

return appointmentDateTime>=now;

}

);

setAppointmentCount(
activeAppointments.length
);

const activePatients=
new Set(

activeAppointments.map(
a=>
a.patient?.patientId
)

);

setPatientCount(
activePatients.size
);

}

catch(error){

console.log(error);

}

};

return(

<MainLayout>

<div className="container mt-4">

<h2>

Admin Dashboard

</h2>

<div className="row">

<div className="col-md-4">

<div className="card shadow p-4">

<h4>

Total Doctors

</h4>

<h1>

{doctorCount}

</h1>

</div>

</div>

<div className="col-md-4">

<div className="card shadow p-4">

<h4>

Active Patients

</h4>

<h1>

{patientCount}

</h1>

</div>

</div>

<div className="col-md-4">

<div className="card shadow p-4">

<h4>

Active Appointments

</h4>

<h1>

{appointmentCount}

</h1>

</div>

</div>

</div>

</div>

</MainLayout>

);

}

export default Dashboard;