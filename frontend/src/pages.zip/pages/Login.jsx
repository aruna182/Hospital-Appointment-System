import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { loginUser } from "../services/AuthService";

function Login() {

    const navigate = useNavigate();

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const handleLogin = async (e) => {

        e.preventDefault();

        try {

            const response = await loginUser({
                username,
                password
            });

            localStorage.setItem(
             "token",
                response.data.token
                );

            localStorage.setItem(
    "role",
    response.data.role
);

            alert(response.data.message);

            navigate("/dashboard");

        } catch (error) {

            alert("Invalid Credentials");

        }

    };

    return (

        <div className="container mt-5">

            <div className="card p-4 shadow">

                <h2 className="text-center mb-4">
                    Login
                </h2>

                <form onSubmit={handleLogin}>

                    <input
                        className="form-control mb-3"
                        placeholder="Username"
                        onChange={(e) =>
                            setUsername(e.target.value)
                        }
                    />

                    <input
                        type="password"
                        className="form-control mb-3"
                        placeholder="Password"
                        onChange={(e) =>
                            setPassword(e.target.value)
                        }
                    />

                    <button className="btn btn-primary w-100">

                        Login

                    </button>

                </form>

                <br />

                <Link to="/register">

                    New User? Register

                </Link>

            </div>

        </div>

    );
}

export default Login;