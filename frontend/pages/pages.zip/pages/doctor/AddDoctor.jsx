import { useState } from "react";
import { addDoctor } from "../services/ApiService";

function AddDoctor() {

    const [doctorName, setDoctorName] = useState("");
    const [specialization, setSpecialization] = useState("");
    const [experience, setExperience] = useState("");

    const saveDoctor = () => {

        addDoctor({
            doctorName,
            specialization,
            experience
        });

        alert("Doctor Added Successfully");
    };

    return (

        <div>

            <h2>Add Doctor</h2>

            <input
                placeholder="Doctor Name"
                onChange={(e) => setDoctorName(e.target.value)}
            />

            <br /><br />

            <input
                placeholder="Specialization"
                onChange={(e) => setSpecialization(e.target.value)}
            />

            <br /><br />

            <input
                placeholder="Experience"
                onChange={(e) => setExperience(e.target.value)}
            />

            <br /><br />

            <button onClick={saveDoctor}>
                Save
            </button>

        </div>
    );
}

export default AddDoctor;