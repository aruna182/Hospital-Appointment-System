import { useState } from "react";
import api from "../services/api";

function Register() {

 const [user,setUser]=useState({
   username:"",
   password:"",
   role:"ADMIN"
 });

 const register=async()=>{

   await api.post(
      "/auth/register",
      user
   );

   alert("Registered");
 };

 return(
   <div>

    <h2>Register</h2>

    <input
    placeholder="Username"
    onChange={(e)=>
      setUser({
      ...user,
      username:e.target.value
    })}
    />

    <br/><br/>

    <input
    placeholder="Password"
    onChange={(e)=>
      setUser({
      ...user,
      password:e.target.value
    })}
    />

    <br/><br/>

    <button onClick={register}>
      Register
    </button>

   </div>
 );
}

export default Register;