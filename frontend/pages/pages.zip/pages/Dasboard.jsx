function Dashboard() {
    return (
        <div>
            <h1>Hospital Appointment Management System</h1>

            <h3>Modules</h3>

            <ul>
                <li>Doctor Management</li>
                <li>Patient Management</li>
                <li>Appointment Management</li>
            </ul>
        </div>
    );
}

export default Dashboard;