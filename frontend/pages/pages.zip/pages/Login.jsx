import { useState } from "react";
import api from "../services/api";

function Login() {

  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");

  const login=async()=>{

    const response = await api.post(
      "/auth/login",
      {
        username,
        password
      }
    );

    localStorage.setItem(
      "token",
      response.data.token
    );

    alert("Login Success");
  };

  return(
    <div>
      <h2>Login</h2>

      <input
      placeholder="Username"
      onChange={(e)=>
      setUsername(e.target.value)}
      />

      <br/><br/>

      <input
      type="password"
      placeholder="Password"
      onChange={(e)=>
      setPassword(e.target.value)}
      />

      <br/><br/>

      <button onClick={login}>
      Login
      </button>
    </div>
  );
}

export default Login;